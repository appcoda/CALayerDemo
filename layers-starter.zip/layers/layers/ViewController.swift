//
//  ViewController.swift
//  layers
//
//  Created by Pranjal Satija on 5/14/16.
//  Copyright © 2016 Pranjal Satija. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet private var box: UIView!
    
    override func viewDidLoad() {


    }
}